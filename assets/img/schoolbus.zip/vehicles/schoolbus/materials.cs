
singleton Material(schoolbus)
{
	mapTo = "schoolbus";
	diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
	instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_dual)
{
	mapTo = "schoolbus_dual";
	diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
	instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus.skin.school")
{
	mapTo = "schoolbus.skin.school";
	overlayMap[2] = "schoolbus_skin_school";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.school")
{
	mapTo = "schoolbus_dual.skin.school";
	overlayMap[2] = "schoolbus_skin_school";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.prison")
{
	mapTo = "schoolbus.skin.prison";
	overlayMap[2] = "schoolbus_skin_prison";
	diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.prison")
{
	mapTo = "schoolbus_dual.skin.prison";
	overlayMap[2] = "schoolbus_skin_prison";
	diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material("schoolbus.skin.derbyblack")
{
	mapTo = "schoolbus.skin.derbyblack";
	overlayMap[2] = "schoolbus_skin_derbyblack";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.derbyblack")
{
	mapTo = "schoolbus_dual.skin.derbyblack";
	overlayMap[2] = "schoolbus_skin_derbyblack";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.derbyblue")
{
	mapTo = "schoolbus.skin.derbyblue";
	overlayMap[2] = "schoolbus_skin_derbyblue";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.derbyblue")
{
	mapTo = "schoolbus_dual.skin.derbyblue";
	overlayMap[2] = "schoolbus_skin_derbyblue";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.derbyred")
{
	mapTo = "schoolbus.skin.derbyred";
	overlayMap[2] = "schoolbus_skin_derbyred";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.derbyred")
{
	mapTo = "schoolbus_dual.skin.derbyred";
	overlayMap[2] = "schoolbus_skin_derbyred";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.plain")
{
	mapTo = "schoolbus.skin.plain";
	overlayMap[2] = "schoolbus_skin_schoolplain";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.plain")
{
	mapTo = "schoolbus_dual.skin.plain";
	overlayMap[2] = "schoolbus_skin_schoolplain";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.dozer")
{
	mapTo = "schoolbus.skin.dozer";
	overlayMap[2] = "schoolbus_skin_dozer";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.dozer")
{
	mapTo = "schoolbus_dual.skin.dozer";
	overlayMap[2] = "schoolbus_dual_skin_dozer";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d";//use 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus.skin.drift")
{
	mapTo = "schoolbus.skin.drift";
	overlayMap[2] = "schoolbus_skin_drift";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.drift")
{
	mapTo = "schoolbus_dual.skin.drift";
	overlayMap[2] = "schoolbus_skin_drift";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus.skin.drag")
{
	mapTo = "schoolbus.skin.drag";
	colorPaletteMap[2] = "schoolbus_skin_drag_uv1";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_dual.skin.drag")
{
	mapTo = "schoolbus_dual.skin.drag";
	colorPaletteMap[2] = "schoolbus_skin_drag_uv1";
    diffuseMap[2] = "schoolbus_c";
    specularMap[2] = "schoolbus_s";
    normalMap[2] = "schoolbus_n";
    diffuseMap[1] = "schoolbus_dual_d"; 
    specularMap[1] = "schoolbus_s";
    normalMap[1] = "schoolbus_n";
    diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    specularPower[2] = "8";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_grille)
{
    mapTo = "schoolbus_grille";
    diffuseMap[1] = "schoolbus_grille";
    specularMap[1] = "schoolbus_grille";
    normalMap[1] = "wings_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "wings_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.8 0.8 0.8";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(wall_walltex)
{
    mapTo = "walltex";
    diffuseMap[1] = "wall_d";
    specularMap[1] = "wall_s";
    normalMap[1] = "wall_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "wall_n";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(strap22)
{
    mapTo = "strap22";
    diffuseMap[1] = "schoolbus_strap_c";
    //specularMap[1] = "schoolbus_strap_s";
    normalMap[1] = "schoolbus_strap_n";
    diffuseMap[0] = "vehicles/common/null";
    //specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_strap_n";
    specularPower[0] = "0";
    pixelSpecular[0] = "0";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(barstow_engine_v8)
{
    mapTo = "barstow_engine_v8";
    diffuseMap[1] = "vehicles/barstow/barstow_engine_v8_d";
    specularMap[1] = "vehicles/barstow/barstow_engine_v8_s";
    normalMap[1] = "vehicles/barstow/barstow_engine_v8_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/barstow/barstow_engine_v8_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.6 0.6 0.6 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(wings)
{
    mapTo = "wings";
    diffuseMap[1] = "wings_d";
    specularMap[1] = "wings_s";
    normalMap[1] = "wings_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "wings_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(wings_grey)
{
	mapTo = "wings_grey";
	specularPower[0] = "128";
	pixelSpecular[0] = "1";
	diffuseColor[0] = "0.16 0.16 0.16 1";
	useAnisotropic[0] = "1";
	castShadows = "1";
	translucent = "1";
	translucentBlendOp = "None";
	alphaTest = "0";
	alphaRef = "0";
	dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(citybus_jato)
{
   mapTo = "citybus_jato";
    diffuseMap[0] = "vehicles/citybus/citybus_jato_d";
    specularMap[0] = "vehicles/citybus/citybus_jato_s";
    normalMap[0] = "vehicles/citybus/citybus_jato_n";
    reflectivityMap[0] = "vehicles/citybus/citybus_jato_r";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    emissive[0] = "0";
    glow[0] = "0";
    translucentBlendOp = "None";
    cubemap = "global_cubemap_metalblurred";
    alphaTest = "0";
    alphaRef = "64";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(shockdiamonds_L)
{
    mapTo = "shockdiamonds_L";
};

singleton Material(shockdiamonds_R)
{
    mapTo = "shockdiamonds_R";
};

singleton Material(shockdiamonds_glow)
{
   mapTo = "shockdiamonds_glow";
   vertColor[0] = "1";
   diffuseMap[0] = "vehicles/citybus/shockdiamonds_d";
   pixelSpecular[0] = "0";
   doubleSided = "0";
   emissive[0] = 1;
   glow[0] = 1;
   translucent = "1";
   translucentBlendOp = "addAlpha";
   animFlags[0] = "0x00000010";
   sequenceFramePerSec[0] = "120";
   sequenceSegmentSize[0] = "0.01";
   useAnisotropic[0] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(semi_turbo_ultra)
{
    mapTo = "semi_turbo_ultra";
    diffuseMap[1] = "semi_turbo_ultra";
    specularMap[1] = "semi_turbo_ultra_s";
    normalMap[1] = "semi_turbo_ultra_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_turbo_ultra_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.1 1.1 1.1 0.9";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_engine_acert)
{
    mapTo = "semi_engine_acert";
    diffuseMap[1] = "semi_engine_acert";
    specularMap[1] = "semi_engine_s";
    normalMap[1] = "semi_engine_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_engine_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(offroadtire_PREMIUM)
{
    mapTo = "offroadtire_PREMIUM";
    diffuseMap[1] = "offroadtire_PREMIUM";
    specularMap[1] = "vehicles/common/tires/offroadtire_01a_s";
    normalMap[1] = "vehicles/common/tires/offroadtire_01a_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/tires/offroadtire_01a_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1.1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(offroadtire_GRIP)
{
    mapTo = "offroadtire_GRIP";
    diffuseMap[1] = "offroadtire_GRIP";
    specularMap[1] = "vehicles/common/tires/offroadtire_01a_s";
    normalMap[1] = "vehicles/common/tires/offroadtire_01a_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/tires/offroadtire_01a_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1.1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(dummy_mat)
{
   mapTo = "dummy";
   diffuseMap[0] = "Dummy.png";
   specular[0] = "0.996078 0.996078 0.996078 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
   detailScale[0] = "4 4";
   materialTag0 = "Miscellaneous";
   detailMapScale0 = "5";
   beamngDiffuseColorSlot = "2";
   doubleSided = "1";
   pixelSpecular[0] = "1";
};
singleton Material(schoolbus_frame)
{
    mapTo = "schoolbus_frame";
    diffuseMap[1] = "schoolbus_frame_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.15 0.15 0.17 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(schoolbus_frame_dual)
{
    mapTo = "schoolbus_frame_dual";
    diffuseMap[1] = "schoolbus_frame_dual_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.15 0.15 0.17 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(schoolbus_frame_offroad)
{
    mapTo = "schoolbus_frame_offroad";
    diffuseMap[1] = "schoolbus_frame_offroad_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.15 0.15 0.17 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};
singleton Material(schoolbus_exhaust_straight)
{
    mapTo = "schoolbus_exhaust_straight";
    diffuseMap[1] = "schoolbus_exhaust_straight_d";
    specularMap[1] = "schoolbus_exhaust_straight_s";
    normalMap[1] = "schoolbus_normal";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_normal";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.87";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_dual_manifold)
{
    mapTo = "schoolbus_dual_manifold";
    diffuseMap[1] = "schoolbus_dual_exhaust_d";
    specularMap[1] = "schoolbus_dual_exhaust_s";
    normalMap[1] = "schoolbus_normal";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_normal";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.7";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_exhaust_quad)
{
    mapTo = "schoolbus_exhaust_quad";
    diffuseMap[1] = "schoolbus_exhaust_quad_d";
    specularMap[1] = "schoolbus_exhaust_quad_s";
    normalMap[1] = "schoolbus_normal";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "schoolbus_normal";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.4";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(schoolbus_offroad_tire)
{
    mapTo = schoolbus_offroad_tire;
    diffuseMap[1] = "OffRoadTire_2096_1_dark";
    specularMap[1] = "OffRoadTire_2096_1_dark";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.2 0.2 0.2 1";
    diffuseColor[1] = "0.2 0.2 0.2 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(air_intake)
{
    mapTo = air_intake;
    diffuseMap[1] = "schoolbus_intake_na";
    specularMap[1] = "schoolbus_intake_na";
    //normalMap[1] = "schoolbus_offroad_tire_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    //normalMap[0] = "schoolbus_offroad_tire_n";
    specularPower[0] = "1";
    pixelSpecular[0] = "1";
    specularPower[1] = "1";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_bigfoot_tires)
{
    mapTo = schoolbus_bigfoot_tires;
    diffuseMap[1] = "schoolbus_bigfoot_tires";
    specularMap[1] = "schoolbus_bigfoot_tires";
    //normalMap[1] = "schoolbus_offroad_tire_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    //normalMap[0] = "schoolbus_offroad_tire_n";
    specularPower[0] = "1";
    pixelSpecular[0] = "1";
    specularPower[1] = "1";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.1 0.1 0.1 1";
    diffuseColor[1] = "0.1 0.1 0.1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_seats)
{
    mapTo = schoolbus_seats;
    diffuseMap[1] = "schoolbus_leather_brown";
	diffuseColor[1] = "1 1 1 0.92"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "0";
    pixelSpecular[0] = "0";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material("schoolbus_seats.skin_interior.grey")
{
	mapTo = "schoolbus_seats.skin_interior.grey";
    diffuseMap[1] = "schoolbus_leather_grey"; 
	diffuseColor[1] = "1 1 1 0.92"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "0";
    pixelSpecular[0] = "0";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};





singleton Material("schoolbus_seats.skin_interior.blue")
{
	mapTo = "schoolbus_seats.skin_interior.blue";
    diffuseMap[1] = "schoolbus_leather_blue"; 
	diffuseColor[1] = "1 1 1 0.92"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "0";
    pixelSpecular[0] = "0";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_interior)
{
    mapTo = "schoolbus_interior";
    diffuseMap[1] = "schoolbus_interior_d"; 
    specularMap[1] = "schoolbus_interior_s"; 
    normalMap[1] = "schoolbus_interior_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_interior_n";
    specularPower[0] = "0";
    pixelSpecular[0] = "0";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(kidsstuff)
{
    mapTo = "kidsstuff";
    diffuseMap[1] = "kidsstuff"; 
    specularMap[1] = "kidsstuff_s"; 
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(steelwheel_12a_black)
{
    mapTo = "steelwheel_12a_black";
    diffuseMap[1] = "vehicles/common/wheels/steelwheel_12a_d";
    specularMap[1] = "vehicles/common/wheels/steelwheel_12a_s";
    normalMap[1] = "vehicles/common/wheels/steelwheel_12a_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "vehicles/common/wheels/steelwheel_12a_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "0";
    pixelSpecular[1] = "0";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.1 0.1 0.1 0.9";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};
singleton Material(schoolbus_ehatch)
{
    mapTo = "schoolbus_ehatch";
    diffuseMap[1] = "schoolbus_ehatch1";
    diffuseMap[0] = "schoolbus_ehatch1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_driveshaft_d)
{
    mapTo = "schoolbus_driveshaft_d";
    diffuseMap[1] = "schoolbus_driveshaft_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null"; 
    specularPower[0] = "1";
    pixelSpecular[0] = "0";
    specularPower[1] = "1";
    pixelSpecular[1] = "0";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.18 0.18 0.2 0.999";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};
singleton Material(schoolbus_engbaycrap)
{
    mapTo = "schoolbus_engbaycrap";
    diffuseMap[1] = "schoolbus_engbaycrap1"; 
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_steplight)
{
    mapTo = "bus_steplight";
    diffuseMap[1] = "schoolbus_lights_d"; 
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_reflector)
{
	mapTo = "schoolbus_reflector";
	diffuseMap[1] = "schoolbus_reflectors";
	diffuseMap[0] = "schoolbus_reflectors";	
	diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    specularPower[0] = "132";
    pixelSpecular[0] = "0";
    specularPower[1] = "32";
    pixelSpecular[1] = "0";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_bumpers)
{
	mapTo = "schoolbus_bumpers";
	diffuseMap[0] = "schoolbus_bumpers";	
	diffuseColor[0] = "1 1 1 1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_dashboard)
{
    mapTo = "schoolbus_dashboard";
    diffuseMap[1] = "schoolbus_dashboard"; 
    diffuseColor[1] = "0.7 0.7 0.7 1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_gastank)
{
    mapTo = "schoolbus_gastank";
    diffuseMap[1] = "schoolbus_gastank";
    specularMap[1] = "schoolbus_gastank_s";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.93";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(roadsigns_01)
{
    mapTo = "roadsigns_01";
    diffuseMap[0] = "vehicles/roadsigns/roadsigns_01_d";
    specularMap[0] = "Vehicles/roadsigns/roadsigns_01_s";
    normalMap[0] = "Vehicles/roadsigns/roadsigns_01_n";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1.5 1.5 1.5 1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "object";
};
singleton Material(schoolbus_glass)
{
    mapTo = "schoolbus_glass";
    reflectivityMap[0] = "vehicles/common/glass_base";
    diffuseMap[0] = "schoolbus_glass_d";
    opacityMap[0] = "schoolbus_glass_d";
	diffuseMap[1] = "schoolbus_glass_da";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/null_n";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_glass_dmg)
{
    mapTo = "schoolbus_glass_dmg";
    diffuseMap[0] = "schoolbus_glass_dmg";
    opacityMap[0] = "schoolbus_glass_dmg";
    specularMap[0] = "vehicles/common/glass_dmg_s";
    normalMap[0] = "vehicles/common/glass_dmg_n";
    diffuseMap[1] = "schoolbus_glass_dmg";
    specularMap[1] = "vehicles/common/glass_dmg_s";
    normalMap[1] = "vehicles/common/glass_dmg_n";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
//DELETE? v
singleton Material(schoolbus_headlight_cover)
{
    mapTo = "schoolbus_headlight_cover";
    diffuseMap[0] = "schoolbus_headlight_cover";
    specularMap[0] = "schoolbus_headlight_cover_s";
    normalMap[0] = "schoolbus_headlight_cover_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_int)
{
    mapTo = "bus_red_int";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0 0 0.05";
    diffuseColor[1] = "0.8 0 0 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_int_on)
{
    mapTo = "bus_red_int_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 1";
    diffuseColor[2] = "0.8 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_on)
{
    mapTo = "bus_red_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 1";
    diffuseColor[2] = "0.8 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_on_intense)
{
    mapTo = "bus_red_on_intense";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 2.8";
    diffuseColor[2] = "0.8 0 0 2.8";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_front_hazard)
{
    mapTo = "bus_red_front_hazard";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 0 0 1";
    diffuseColor[1] = "1 0 0 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1 0 0 1.5";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_red_front_hazard_on)
{
    mapTo = "bus_red_front_hazard_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 0 0 1";
    diffuseColor[2] = "1 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_betty_on)
{
    mapTo = "bus_betty_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_amber_signal_L_int)
{
    mapTo = "bus_amber_signal_L_int";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_amber_signal_L_on)
{
    mapTo = "bus_amber_signal_L_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_amber_signal_R_int)
{
    mapTo = "bus_amber_signal_R_int";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 0.3";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_amber_signal_R_on)
{
    mapTo = "bus_amber_signal_R_on";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_white_off)
{
    mapTo = "bus_white_off";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 0.05";
    diffuseColor[1] = "1 1 1 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(bus_white_onn)
{
    mapTo = "bus_white_onn";
	diffuseMap[0] = "vehicles/common/null";
	diffuseMap[1] = "moonhawk_lights_d";
    diffuseMap[2] = "moonhawk_lights_g";
	specularMap[0] = "vehicles/common/null";
	specularMap[1] = "moonhawk_lights_s";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[0] = "moonhawk_lights_n";
    normalMap[1] = "moonhawk_lights_n";
    normalMap[2] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_lights_d)
{
    mapTo = "schoolbus_lights_d";
    diffuseMap[1] = "schoolbus_lights_d";
    specularMap[1] = "schoolbus_lights_s";
    normalMap[1] = "schoolbus_lights_n";
    diffuseMap[0] = "schoolbus_lights_d";
    specularMap[0] = "schoolbus_lights_s";
    normalMap[0] = "schoolbus_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.2 1.2 1.2 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_lights_d_on)
{
    mapTo = "schoolbus_lights_d_on";
    diffuseMap[2] = "schoolbus_lights_g";
    specularMap[2] = "schoolbus_lights_s";
    normalMap[2] = "schoolbus_lights_n";
    diffuseMap[1] = "schoolbus_lights_d";
    specularMap[1] = "schoolbus_lights_s";
    normalMap[1] = "schoolbus_lights_n";
    diffuseMap[0] = "schoolbus_lights_d";
    specularMap[0] = "schoolbus_lights_d";
    normalMap[0] = "schoolbus_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.2";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_lights_d_on_intense)
{
    mapTo = "schoolbus_lights_d_on_intense";
    diffuseMap[2] = "schoolbus_lights_g";
    specularMap[2] = "schoolbus_lights_s";
    normalMap[2] = "schoolbus_lights_n";
    diffuseMap[1] = "schoolbus_lights_d";
    specularMap[1] = "schoolbus_lights_s";
    normalMap[1] = "schoolbus_lights_n";
    diffuseMap[0] = "schoolbus_lights_d";
    specularMap[0] = "schoolbus_lights_d";
    normalMap[0] = "schoolbus_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.2";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_lights_dmg_d)
{
    mapTo = "schoolbus_lights_dmg_d";
    diffuseMap[1] = "schoolbus_lights_dmg_d";
    specularMap[1] = "schoolbus_lights_dmg_s";
    normalMap[1] = "schoolbus_lights_dmg_n";
    diffuseMap[0] = "schoolbus_lights_dmg_d";
    specularMap[0] = "schoolbus_lights_dmg_s";
    normalMap[0] = "schoolbus_lights_dmg_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_seatpost)
{
    mapTo = "schoolbus_seatpost";
    diffuseMap[1] = "schoolbus_seat_post_c";
    specularMap[1] = "schoolbus_seat_post_s";
    normalMap[1] = "schoolbus_seat_post_n";
    diffuseMap[0] = "schoolbus_seat_post_c";
    specularMap[0] = "schoolbus_seat_post_s";
    normalMap[0] = "schoolbus_seat_post_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(beaconlight)
{
    mapTo = "beaconlight";
    diffuseMap[0] = "vehicles/common/beaconlight_d";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/beaconlight_n";
    diffuseMap[1] = "vehicles/common/beaconlight_red_da";
    specularMap[1] = "vehicles/common/null";
    normalMap[1] = "vehicles/common/beaconlight_n";
    diffuseMap[2] = "vehicles/common/beaconlight_g";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "0";
    translucent = "0";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(beaconlight_glass)
{
    mapTo = "beaconlight_glass";
    diffuseMap[0] = "vehicles/common/beaconlight_d";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/beaconlight_n";
    diffuseMap[1] = "vehicles/common/beaconlight_d";
    specularMap[1] = "vehicles/common/null";
    normalMap[1] = "vehicles/common/beaconlight_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_betty_inner)
{
    mapTo = "schoolbus_betty_inner";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "0.7 0.7 0.7 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
//Basic Colors
singleton Material(chrome)
{
   mapTo = "chrome";
	diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "0.2 0.2 0.2 0.6";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(chrome2)
{
   mapTo = "chrome2";
	diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "0.5 0.5 0.5 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_police_ram)
{
   mapTo = "schoolbus_police_ram";
	diffuseMap[0] = "schoolbus_police_ram";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "0.2 0.2 0.2 0.3";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_rollcage_black)
{
    mapTo = "schoolbus_rollcage_black";
    diffuseMap[1] = "schoolbus_rollcage_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.12 0.12 0.12 0.9";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_rollcage_white)
{
    mapTo = "schoolbus_rollcage_white";
    diffuseMap[1] = "schoolbus_rollcage_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.8 0.8 0.9";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(schoolbus_rollcage_red)
{
    mapTo = "schoolbus_rollcage_red";
    diffuseMap[1] = "schoolbus_rollcage_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.1 0.1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_rollcage_yellow)
{
    mapTo = "schoolbus_rollcage_yellow";
    diffuseMap[1] = "schoolbus_rollcage_d";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.55 0.003 0.9";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

//solid colors

singleton Material(black_m)
{
	mapTo = "black_m";
    specularPower[0] = "128";
    pixelSpecular[0] = "0";
    diffuseColor[0] = "0.1 0.1 0.1 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(black_g)
{
    mapTo = "black_g";
	diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0 0 0 0.9";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(silver)
{
   mapTo = "silver";
	diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.5 0.5 0.5 0";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(grey)
{
	mapTo = "grey";
	diffuseMap[0] = "vehicles/common/null";
	specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.45 0.45 0.45 0.6";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

//SEMI

singleton Material(semi_cab)
{
    mapTo = "semi_cab";
    diffuseMap[2] = "semi_cab_c";
    specularMap[2] = "semi_cab_s";
    normalMap[2] = "semi_cab_n";
    diffuseMap[1] = "semi_cab_d";
    specularMap[1] = "semi_cab_s";
    normalMap[1] = "semi_cab_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_cab_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_semi_engine)
{
    mapTo = "schoolbus_semi_engine";
    diffuseMap[1] = "semi_engine_d";
    specularMap[1] = "semi_engine_s";
    normalMap[1] = "semi_engine_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_engine_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(semi_engine_volvo)
{
    mapTo = "semi_engine_volvo";
    diffuseMap[1] = "semi_engine_volvo";
    specularMap[1] = "semi_engine_s";
    normalMap[1] = "semi_engine_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_engine_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_gauges)
{
    mapTo = "semi_gauges";
    diffuseMap[0] = "semi_gauges_d";
    specularMap[0] = "semi_gauges_s";
    normalMap[0] = "semi_gauges_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
};
singleton Material(semi_interior)
{
    mapTo = "semi_interior";
    normalMap[0] = "semi_interior_n";
    diffuseMap[0] = "semi_interior_d";
    specularMap[0] = "semi_interior_s";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    specularPower[1] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(schoolbus_semi_frame)
{
    mapTo = "schoolbus_semi_frame";
    diffuseMap[1] = "semi_frame_d";
    specularMap[1] = "semi_frame_s";
    normalMap[1] = "semi_frame_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_frame_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(semi_mudflap)
{
    mapTo = "semi_mudflap";
    diffuseMap[0] = "semi_mudflap_d";
    normalMap[0] = "semi_mudflap_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    specularMap[0] = "semi_mudflap_s";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
};
singleton Material(semi_engine)
{
    mapTo = "semi_engine";
    diffuseMap[1] = "semi_engine_d";
    specularMap[1] = "semi_engine_s";
    normalMap[1] = "semi_engine_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "semi_engine_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
//VAN
singleton Material(van_seats)
{
    mapTo = "van_seats";
    diffuseMap[0] = "van_seats_d";
    specularMap[0] = "van_seats_s";
    normalMap[0] = "van_seats_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1.5 1.5 1.5 1";
};
singleton Material(van_interior)
{
    mapTo = "van_interior";
    diffuseMap[0] = "van_interior_d";
    specularMap[0] = "van_interior_s";
    normalMap[0] = "van_interior_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1.5 1.5 1.5 1";
};
singleton Material(van_gauges)
{
    mapTo = "van_gauges";
    diffuseMap[0] = "van_gauges_d";
    specularMap[0] = "van_gauges_s";
    normalMap[0] = "van_gauges_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1.5 1.5 1.5 1";
};
singleton Material(van_glass)
{
    mapTo = "van_glass";
    reflectivityMap[0] = "vehicles/common/glass_base";
    diffuseMap[0] = "van_glass_d";
    opacityMap[0] = "van_glass_d";
    diffuseMap[1] = "van_glass_da";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/common/null_n";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(van_glass_int)
{
    mapTo = "van_glass_int";
    diffuseMap[0] = "van_glass_d";
    specularMap[0] = "vehicles/common/null";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(van_glass_dmg)
{
    mapTo = "van_glass_dmg";
    diffuseMap[0] = "van_glass_dmg_d";
    opacityMap[0] = "van_glass_dmg_d";
    specularMap[0] = "vehicles/common/glass_dmg_s";
    normalMap[0] = "vehicles/common/glass_dmg_n";
    diffuseMap[1] = "van_glass_dmg_d";
    specularMap[1] = "vehicles/common/glass_dmg_s";
    normalMap[1] = "vehicles/common/glass_dmg_n";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(van_seats)
{
    mapTo = "van_seats";
    diffuseMap[0] = "van_seats_d";
    specularMap[0] = "van_seats_s";
    normalMap[0] = "van_seats_n";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1.5 1.5 1.5 1";
};
//MOONHAWK
singleton Material(moonhawk_lights)
{
    mapTo = "moonhawk_lights";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.3 1.3 1.3 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights_on)
{
    mapTo = "moonhawk_lights_on";
    diffuseMap[2] = "moonhawk_lights_g";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[2] = "moonhawk_lights_n";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.15";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(moonhawk_lights_on_intense)
{
    mapTo = "moonhawk_lights_on_intense";
    diffuseMap[2] = "moonhawk_lights_g";
    specularMap[2] = "moonhawk_lights_s";
    normalMap[2] = "moonhawk_lights_n";
    diffuseMap[1] = "moonhawk_lights_d";
    specularMap[1] = "moonhawk_lights_s";
    normalMap[1] = "moonhawk_lights_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.3";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(moonhawk_lights_dmg)
{
    mapTo = "moonhawk_lights_dmg";
    diffuseMap[1] = "moonhawk_lights_dmg_d";
    specularMap[1] = "moonhawk_lights_dmg_s";
    normalMap[1] = "moonhawk_lights_dmg_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "moonhawk_lights_dmg_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material(moonhawk_lights_dmg_alt)
{
    mapTo = "moonhawk_lights_dmg_alt";
    diffuseMap[0] = "moonhawk_lights_dmg_d";
    diffuseColor[0] = "1 1 1 1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
//HOPPER
singleton Material(hopper)
{
   mapTo = "hopper";
    diffuseMap[2] = "vehicles/hopper/hopper_c";
    specularMap[2] = "vehicles/hopper/hopper_s";
    normalMap[2] = "vehicles/hopper/hopper_n";
    diffuseMap[1] = "vehicles/hopper/hopper_d";
    specularMap[1] = "vehicles/hopper/hopper_s";
    normalMap[1] = "vehicles/hopper/hopper_n";
    diffuseMap[0] = "vehicles/common/null";
    specularMap[0] = "vehicles/common/null";
    normalMap[0] = "vehicles/hopper/hopper_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
//STIG
singleton Material(stig_body)
{
   mapTo = "Stig";
   diffuseMap[0] = "Stig";
   normalMap[0] = "Stig_normal";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
   materialTag0 = "stig"; materialTag1 = "driver";
};
singleton Material(stig_helmet)
{
   mapTo = "Stig_helmet";
   diffuseMap[0] = "Stig_helmet";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
   materialTag0 = "stig"; materialTag1 = "driver";
};
singleton Material(stig_visor)
{
   mapTo = "Visor";
   diffuseMap[0] = "Stig_visor";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
   materialTag0 = "stig"; materialTag1 = "driver";
};
//LIGHT HOOKS
singleton Material(van_headlight)
{
    mapTo = "van_headlight";
};
singleton Material(semi_signal_L)
{
    mapTo = "semi_signal_L";
};
singleton Material(semi_signal_R)
{
    mapTo = "semi_signal_R";
};
singleton Material(bus_reverselight)
{
    mapTo = "schoolbus_reverselight";
};
singleton Material(bus_signal_L)
{
    mapTo = "schoolbus_signal_L";
};
singleton Material(bus_signal_R)
{
    mapTo = "schoolbus_signal_R";
};
singleton Material(bus_taillight)
{
    mapTo = "schoolbus_taillight";
};
singleton Material(bus_hazard)
{
    mapTo = "schoolbus_hazard";
};
singleton Material(schoolbus_betty_lights)
{
    mapTo = "schoolbus_betty_lights";
};
singleton Material(bus_white_light)
{
    mapTo = "bus_white_light";
};
singleton Material(bus_red)
{
    mapTo = "bus_red";
};
singleton Material(schoolbus_lowbeam)
{
    mapTo = "schoolbus_lowbeam";
};
singleton Material(bus_amber_signal_R)
{
    mapTo = "bus_amber_signal_R";
};
singleton Material(bus_red_int)
{
    mapTo = "bus_red_int";
};
singleton Material(bus_amber_signal_L)
{
    mapTo = "bus_amber_signal_L";
};
singleton Material(bus_amber_harzard)
{
    mapTo = "bus_amber_harzard";
};
singleton Material(bus_red_front_hazard)
{
    mapTo = "bus_red_front_hazard";
};