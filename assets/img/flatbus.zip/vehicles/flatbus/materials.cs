

singleton Material(wings)
{
    mapTo = "wings";
    diffuseMap[1] = "wings_d";
    specularMap[1] = "wings_s";
    normalMap[1] = "wings_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "wings_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(wings_grey)
{
	mapTo = "wings_grey";
	specularPower[0] = "128";
	pixelSpecular[0] = "1";
	diffuseColor[0] = "0.16 0.16 0.16 1";
	useAnisotropic[0] = "1";
	castShadows = "1";
	translucent = "1";
	translucentBlendOp = "None";
	alphaTest = "0";
	alphaRef = "0";
	dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(grey)
{
    mapTo = "grey";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "0.35 0.35 0.35 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(flatbus_drag_exhaust)
{
    mapTo = "flatbus_drag_exhaust";
    diffuseMap[1] = "vehicles/flatbus/flatbus_drag_exhaust_d";
    specularMap[1] = "vehicles/flatbus/flatbus_drag_exhaust_s";
    normalMap[1] = "vehicles/flatbus/flatbus_normal";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_normal";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.8";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};



singleton Material(flatbus_rollcage)
{
    mapTo = "flatbus_rollcage";
    diffuseMap[1] = "vehicles/flatbus/flatbus_rollcage_d";
    specularMap[1] = "vehicles/flatbus/flatbus_rollcage_d";
    normalMap[1] = "vehicles/flatbus/flatbus_normal";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_normal";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 0.1 0.1 1";
    diffuseColor[1] = "1 0.1 0.1 0.7";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};



singleton Material(flatbus_mesh2)
{
    mapTo = "flatbus_mesh2";
    diffuseMap[0] = "vehicles/flatbus/flatbus_mesh2_d";	
    diffuseColor[0] = "0.7 0.7 0.7 1"; 
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	translucentBlendOp = "LerpAlpha";
    transparency = "1";
	doubleSided = "1";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_tube)
{
    mapTo = "flatbus_tube";
    diffuseMap[0] = "vehicles/flatbus/flatbus_tube_d.dds";	
    diffuseColor[0] = "0.5 0.5 0.5 1"; 
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	translucentBlendOp = "LerpAlpha";
    transparency = "1";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(barstow_engine_v8)
{
    mapTo = "barstow_engine_v8";
    diffuseMap[1] = "vehicles/flatbus/barstow_engine_v8_d";
    specularMap[1] = "vehicles/flatbus/barstow_engine_v8_s";
    normalMap[1] = "vehicles/flatbus/barstow_engine_v8_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/barstow_engine_v8_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 0.6";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(oilcooler)
{
    mapTo = "oilcooler";
    diffuseMap[1] = "vehicles/common/oilcooler_d";
    specularMap[1] = "vehicles/common/oilcooler_s";
    normalMap[1] = "vehicles/common/oilcooler_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/oilcooler_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_supercharger_intake)
{
    mapTo = "flatbus_supercharger_intake";
    diffuseMap[1] = "vehicles/flatbus/flatbus_supercharger_intake_d";
    specularMap[1] = "vehicles/flatbus/flatbus_supercharger_intake_s";
    normalMap[1] = "vehicles/flatbus/flatbus_supercharger_intake_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_supercharger_intake_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_tube)
{
    mapTo = "flatbus_tube";
    diffuseMap[1] = "vehicles/flatbus/flatbus_supercharger_tube_d";
    specularMap[1] = "vehicles/flatbus/flatbus_supercharger_tube_s";
    normalMap[1] = "vehicles/flatbus/flatbus_supercharger_tube_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_supercharger_tube_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(semi_engine_acert)
{
    mapTo = "semi_engine_acert";
    diffuseMap[1] = "vehicles/schoolbus/semi_engine_acert";
    specularMap[1] = "vehicles/schoolbus/semi_engine_s";
    normalMap[1] = "vehicles/semi/semi_engine_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/semi/semi_engine_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    diffuseColor[1] = "0.8 0.8 0.8 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    doubleSided = "1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};



//

singleton Material(flatbus)
{
	mapTo = "flatbus";
	overlayMap[2] = "vehicles/flatbus/flatbus_d.dds";
	diffuseMap[2] = "vehicles/flatbus/flatbus_c.dds";
    specularMap[2] = "vehicles/flatbus/flatbus_s.dds";
    normalMap[2] = "vehicles/flatbus/flatbus_n.dds";
    diffuseMap[1] = "vehicles/flatbus/flatbus_d.dds";
    specularMap[1] = "vehicles/flatbus/flatbus_s.dds";
    normalMap[1] = "vehicles/flatbus/flatbus_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("flatbus.skin.school")
{
	mapTo = "flatbus.skin.school";
	overlayMap[2] = "vehicles/flatbus/flatbus_school_1.dds";
    diffuseMap[2] = "vehicles/flatbus/flatbus_c.dds";
    specularMap[2] = "vehicles/flatbus/flatbus_s.dds";
    normalMap[2] = "vehicles/flatbus/flatbus_n.dds";
    diffuseMap[1] = "vehicles/flatbus/flatbus_d.dds";
    specularMap[1] = "vehicles/flatbus/flatbus_s.dds";
    normalMap[1] = "vehicles/flatbus/flatbus_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    specularPower[2] = "128";
    pixelSpecular[2] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    instanceDiffuse[2] = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(schoolbus_seats)
{
    mapTo = schoolbus_seats;
    diffuseMap[1] = "schoolbus_leather_brown";
    diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("schoolbus_seats.skin_interior.grey")
{
	mapTo = "schoolbus_seats.skin_interior.grey";
    diffuseMap[1] = "schoolbus_leather_grey"; 
	diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};
singleton Material("schoolbus_seats.skin_interior.blue")
{
	mapTo = "schoolbus_seats.skin_interior.blue";
    diffuseMap[1] = "schoolbus_leather_blue"; 
	diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("flatbus_seats.skin_interior.black")
{
	mapTo = "flatbus_seats.skin_interior.black";
    diffuseMap[1] = "vehicles/flatbus/flatbus_seats_black_d.dds"; 
	diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "vehicles/flatbus/flatbus_seats_s.dds"; 
    normalMap[1] = "vehicles/flatbus/flatbus_seats_n.dds"; 
    diffuseMap[0] = "vehicles/common/null.dds";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null.dds"; 
    normalMap[0] = "vehicles/flatbus/flatbus_seats_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material("flatbus_seats.skin_interior.blue")
{
	mapTo = "flatbus_seats.skin_interior.blue";
    diffuseMap[1] = "vehicles/flatbus/flatbus_seats_blue_d.dds"; 
	diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "vehicles/flatbus/flatbus_seats_s.dds"; 
    normalMap[1] = "vehicles/flatbus/flatbus_seats_n.dds"; 
    diffuseMap[0] = "vehicles/common/null.dds";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null.dds"; 
    normalMap[0] = "vehicles/flatbus/flatbus_seats_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_interior)
{
    mapTo = "flatbus_interior";
    diffuseMap[1] = "vehicles/flatbus/flatbus_interior.dds"; 
    specularMap[1] = ""; 
    normalMap[1] = ""; 
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds"; 
    normalMap[0] = "";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_undercarrige)
{
    mapTo = "flatbus_undercarrige";
    diffuseMap[1] = "vehicles/flatbus/flatbus_undercarrige.dds"; 
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_vents)
{
    mapTo = "flatbus_vents";
    diffuseMap[0] = "vehicles/flatbus/flatbus_vents.dds";	
    diffuseColor[0] = "0.5 0.5 0.5 1"; 
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	translucentBlendOp = "LerpAlpha";
    transparency = "1";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(schoolbus_seats)
{
    mapTo = schoolbus_seats;
    diffuseMap[1] = "schoolbus_leather_brown";
    diffuseColor[1] = "1 1 1 1"; 
    specularMap[1] = "schoolbus_leather_grey"; 
    normalMap[1] = "schoolbus_leather_n"; 
    diffuseMap[0] = "vehicles/common/null";  
    diffuseColor[0] = "1 1 1 1"; 
    specularMap[0] = "vehicles/common/null"; 
    normalMap[0] = "schoolbus_leather_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(dummy_mat)
{
   mapTo = "dummy";
   diffuseMap[0] = "Dummy";
   specular[0] = "0.996078 0.996078 0.996078 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
   detailScale[0] = "4 4";
   materialTag0 = "Miscellaneous";
   detailMapScale0 = "5";
   beamngDiffuseColorSlot = "2";
   doubleSided = "1";
   pixelSpecular[0] = "1";
};

singleton Material(flatbus_window_holders)
{
    mapTo = "flatbus_window_holders";
    diffuseMap[1] = "vehicles/flatbus/flatbus_window_holders_d";
    specularMap[1] = "vehicles/flatbus/flatbus_window_holders_s";
    normalMap[1] = "vehicles/flatbus/flatbus_window_holders_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_window_holders_n";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
	doubleSided = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(semi_cab)
{
    mapTo = "semi_cab";
    diffuseMap[1] = "vehicles/semi/semi_cab_d.dds";
    specularMap[1] = "vehicles/semi/semi_cab_s.dds";
    normalMap[1] = "vehicles/semi/semi_cab_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/semi/semi_cab_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    instanceDiffuse[2] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_frame)
{
    mapTo = "semi_frame";
    diffuseMap[1] = "vehicles/semi/semi_frame_d.dds";
    specularMap[1] = "vehicles/semi/semi_frame_s.dds";
    normalMap[1] = "vehicles/semi/semi_frame_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/semi/semi_frame_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_sheet_metal)
{
    mapTo = "flatbus_sheet_metal";
    diffuseMap[1] = "flatbus_sheet_metal2";
    //specularMap[1] = "vehicles/semi/semi_frame_s.dds";
    //normalMap[1] = "vehicles/semi/semi_frame_n.dds";
    diffuseMap[0] = "flatbus_sheet_metal2";
    //specularMap[0] = "vehicles/common/null.dds";
    //normalMap[0] = "vehicles/semi/semi_frame_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(citybus_jato)
{
   mapTo = "citybus_jato";
    diffuseMap[0] = "vehicles/citybus/citybus_jato_d.dds";
    specularMap[0] = "vehicles/citybus/citybus_jato_s.dds";
    normalMap[0] = "vehicles/citybus/citybus_jato_n.dds";
    reflectivityMap[0] = "vehicles/citybus/citybus_jato_r.dds";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    emissive[0] = "0";
    glow[0] = "0";
    translucentBlendOp = "None";
    cubemap = "global_cubemap_metalblurred";
    alphaTest = "0";
    alphaRef = "64";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(shockdiamonds_L)
{
    mapTo = "shockdiamonds_L";
};

singleton Material(shockdiamonds_R)
{
    mapTo = "shockdiamonds_R";
};

singleton Material(shockdiamonds_glow)
{
   mapTo = "shockdiamonds_glow";
   vertColor[0] = "1";
   diffuseMap[0] = "vehicles/citybus/shockdiamonds_d.dds";
   pixelSpecular[0] = "0";
   doubleSided = "0";
   emissive[0] = 1;
   glow[0] = 1;
   translucent = "1";
   translucentBlendOp = "addAlpha";
   animFlags[0] = "0x00000010";
   sequenceFramePerSec[0] = "120";
   sequenceSegmentSize[0] = "0.01";
   useAnisotropic[0] = "1";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(semi_glass)
{
    mapTo = "semi_glass";
	reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/common/glass_base.dds";
    specularMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    doubleSided = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_glass_int)
{
    mapTo = "semi_glass_int";
    diffuseMap[0] = "vehicles/semi/semi_glass_d.dds";
    specularMap[0] = "vehicles/common/null.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    doubleSided = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_glass_dmg)
{
    mapTo = "semi_glass_dmg";
    diffuseMap[0] = "vehicles/semi/semi_glass_dmg_d.dds";
    opacityMap[0] = "vehicles/semi/semi_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/semi/semi_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_glass_dmg)
{
    mapTo = "flatbus_glass_dmg";
    diffuseMap[0] = "flatbus_glass_dmg.dds";
    opacityMap[0] = "flatbus_glass_dmg.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "flatbus_glass_dmg.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_glass)
{
    mapTo = "flatbus_glass";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/flatbus/flatbus_glass_d.dds";
    opacityMap[0] = "vehicles/flatbus/flatbus_glass_d.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseMap[1] = "vehicles/flatbus/flatbus_glass_da.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_glass_int)
{
    mapTo = "flatbus_glass_int";
    diffuseMap[0] = "vehicles/flatbus/flatbus_glass_da.dds";
    specularMap[0] = "vehicles/common/null.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    doubleSided = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_dash)
{
    mapTo = "flatbus_dash";
    diffuseMap[0] = "flatbus_dash";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_railing)
{
   mapTo = "flatbus_railing";
    diffuseMap[0] = "flatbus_railing";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(semi_interior)
{
    mapTo = "semi_interior";
    normalMap[0] = "vehicles/semi/semi_interior_n.dds";
    diffuseMap[0] = "vehicles/semi/semi_interior_d.dds";
    specularMap[0] = "vehicles/semi/semi_interior_s.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    specularPower[1] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblurred";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_reflectors)
{
    mapTo = "flatbus_reflectors";
    diffuseMap[0] = "vehicles/flatbus/flatbus_reflectors.dds";
    diffuseColor[0] = "0.8 0.8 0.8 1";
    useAnisotropic[0] = "1";
	specularPower[0] = "32";
    specularPower[1] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(flatbus_mudflaps)
{
    mapTo = "flatbus_mudflaps";
    diffuseMap[0] = "vehicles/flatbus/flatbus_mudflaps.dds";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
	specularPower[0] = "32";
    specularPower[1] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_bumpers)
{
	mapTo = "flatbus_bumpers";
	diffuseMap[1] = "vehicles/flatbus/flatbus_bumpers.dds";
	diffuseMap[0] = "vehicles/flatbus/flatbus_bumpers.dds";	
	diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_hatch)
{
    mapTo = "flatbus_hatch";
    diffuseMap[1] = "vehicles/flatbus/flatbus_hatch.dds";
    specularMap[1] = "vehicles/flatbus/flatbus_hatch_s.dds";
    diffuseMap[0] = "vehicles/flatbus/flatbus_hatch.dds";
    specularMap[0] = "vehicles/flatbus/flatbus_hatch_s.dds";
    diffuseColor[1] = "1 1 1 1";
    specularPower[1] = "32";
    useAnisotropic[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "32";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    cubemap = "global_cubemap_metalblurred";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_frame)
{
	mapTo = "flatbus_frame";
	diffuseMap[1] = "vehicles/flatbus/flatbus_frame.dds";
	diffuseMap[0] = "vehicles/flatbus/flatbus_frame.dds";	
	diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_black)
{
	mapTo = "flatbus_black";
	specularPower[0] = "128";
	pixelSpecular[0] = "1";
	diffuseColor[0] = "0.15 0.15 0.15 1";
	useAnisotropic[0] = "1";
	castShadows = "1";
	translucent = "1";
	translucentBlendOp = "None";
	alphaTest = "0";
	alphaRef = "0";
	dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(sheetmetal)
{
	mapTo = "sheetmetal";
	specularPower[0] = "128";
	pixelSpecular[0] = "1";
	diffuseColor[0] = "0.45 0.45 0.45 1";
	useAnisotropic[0] = "1";
	castShadows = "1";
	translucent = "1";
	translucentBlendOp = "None";
	alphaTest = "0";
	alphaRef = "0";
	dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_black_dull)
{
    mapTo = "flatbus_black_dull";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "0.15 0.15 0.15 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(black_matte_1)
{
    mapTo = "black_matte_1";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "0.15 0.15 0.15 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(grey)
{
    mapTo = "grey";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "0.35 0.35 0.35 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};


singleton Material(flatbus_monitor)
{
	mapTo = "flatbus_monitor";
	diffuseMap[0] = "vehicles/flatbus/flatbus_monitor.dds";		
    specularMap[0] = ""; 
    normalMap[0] = ""; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1"; 
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_engbayrear)
{
	mapTo = "flatbus_engbayrear";
	diffuseMap[0] = "flatbus_engbay"; 
    specularMap[0] = ""; 
    normalMap[0] = ""; 
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1"; 
    useAnisotropic[0] = "1";
	doubleSided = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};	

singleton Material(chrome)
{
   mapTo = "chrome";
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "vehicles/common/null.dds";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "0.7 0.7 0.7 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    doubleSided = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(silver)
{
   mapTo = "silver";
    specularPower[0] = "128";
    specularPower[0] = "32";
    diffuseColor[0] = "0.2 0.2 0.2 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

	
singleton Material(semi_gauges)
{
    mapTo = "semi_gauges";
    diffuseMap[0] = "vehicles/semi/semi_gauges_d.dds";
    specularMap[0] = "vehicles/semi/semi_gauges_s.dds";
    normalMap[0] = "vehicles/semi/semi_gauges_n.dds";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
};

singleton Material(roadsigns_01)
{
    mapTo = "roadsigns_01";
    diffuseMap[0] = "vehicles/roadsigns/roadsigns_01_d.dds";
    specularMap[0] = "vehicles/roadsigns/roadsigns_01_s.dds";
    normalMap[0] = "vehicles/roadsigns/roadsigns_01_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1.5 1.5 1.5 1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(steelwheel_12a)
{
    mapTo = "steelwheel_12a";
    diffuseMap[1] = "vehicles/common/wheels/steelwheel_12a_d.dds";
    specularMap[1] = "vehicles/common/wheels/steelwheel_12a_s.dds";
    normalMap[1] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(steelwheel_12a_color)
{
    mapTo = "steelwheel_12a_color";
    diffuseMap[1] = "vehicles/common/wheels/steelwheel_12a_d.dds";
    specularMap[1] = "vehicles/common/wheels/steelwheel_12a_s.dds";
    normalMap[1] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 0.6";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
	instanceDiffuse[1] = true;
	instanceDiffuse[0] = true;
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(steelwheel_12a_black)
{
    mapTo = "steelwheel_12a_black";
    diffuseMap[1] = "vehicles/common/wheels/steelwheel_12a_d.dds";
    specularMap[1] = "vehicles/common/wheels/steelwheel_12a_s.dds";
    normalMap[1] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/wheels/steelwheel_12a_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "0.1 0.1 0.1 0.2";
    diffuseColor[1] = "0.1 0.1 0.1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

singleton Material(semi_signal_L)
{
    mapTo = "semi_signal_L";
	diffuseColor[0] = "0.1 0.1 0.1 1";
	
};

singleton Material(semi_signal_R)
{
    mapTo = "semi_signal_R";
};

singleton Material(flatbus_engbayfront)
{
	mapTo = "flatbus_engbayfront";
	diffuseMap[0] = "flatbus_engbay_front";	
	diffuseMap[1] = "flatbus_engbay_front";	
	diffuseColor[0] = "1 1 1 1";
	diffuseColor[1] = "1 1 1 1";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(flatbus_red)
{
    mapTo = "flatbus_red";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 0.15 0.15 1";   
    useAnisotropic[0] = "1";   
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
	instanceDiffuse[0] = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_lights)
{
    mapTo = "semi_lights";
    diffuseMap[1] = "vehicles/common/semi_lights_d.dds";
    specularMap[1] = "vehicles/common/semi_lights_s.dds";
    normalMap[1] = "vehicles/common/semi_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/semi_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_lights_on)
{
    mapTo = "semi_lights_on";
    diffuseMap[2] = "vehicles/common/semi_lights_g.dds";
    specularMap[2] = "vehicles/common/semi_lights_s.dds";
    normalMap[2] = "vehicles/common/semi_lights_n.dds";
    diffuseMap[1] = "vehicles/common/semi_lights_d.dds";
    specularMap[1] = "vehicles/common/semi_lights_s.dds";
    normalMap[1] = "vehicles/common/semi_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/semi_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.2";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_lights_on_intense)
{
    mapTo = "semi_lights_on_intense";
    diffuseMap[2] = "vehicles/common/semi_lights_g.dds";
    specularMap[2] = "vehicles/common/semi_lights_s.dds";
    normalMap[2] = "vehicles/common/semi_lights_n.dds";
    diffuseMap[1] = "vehicles/common/semi_lights_d.dds";
    specularMap[1] = "vehicles/common/semi_lights_s.dds";
    normalMap[1] = "vehicles/common/semi_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/semi_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.35";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_lowbeam)
{
    mapTo = "semi_lowbeam";
};

singleton Material(semi_highbeam)
{
    mapTo = "semi_highbeam";
};

singleton Material(flatbus_van_seats)
{
    mapTo = "flatbus_van_seats";
    diffuseMap[0] = "vehicles/flatbus/flatbus_van_seats_d.dds";
    specularMap[0] = "vehicles/flatbus/flatbus_van_seats_s.dds";
    normalMap[0] = "vehicles/flatbus/flatbus_van_seats_n.dds";
    specularPower[0] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1.5 1.5 1.5 1";
};

singleton Material(semi_frame)
{
    mapTo = "semi_frame";
    diffuseMap[1] = "vehicles/semi/semi_frame_d.dds";
    specularMap[1] = "vehicles/semi/semi_frame_s.dds";
    normalMap[1] = "vehicles/semi/semi_frame_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/semi/semi_frame_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(semi_engine)
{
    mapTo = "semi_engine";
    diffuseMap[1] = "vehicles/semi/semi_engine_d.dds";
    specularMap[1] = "vehicles/semi/semi_engine_s.dds";
    normalMap[1] = "vehicles/semi/semi_engine_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/semi/semi_engine_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(barstow_glass_int)
{
    mapTo = "barstow_glass_int";
    diffuseMap[0] = "vehicles/barstow/barstow_glass_d.dds";
    specularMap[0] = "vehicles/common/null.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    doubleSided = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(barstow_glass_dmg)
{
    mapTo = "barstow_glass_dmg";
    diffuseMap[0] = "vehicles/barstow/barstow_glass_dmg_d.dds";
    opacityMap[0] = "vehicles/barstow/barstow_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/barstow/barstow_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_glass)
{
    mapTo = "moonhawk_glass";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/moonhawk/moonhawk_glass_d.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_glass_da.dds";
    specularPower[0] = "8";
    pixelSpecular[0] = "8";
    specularPower[1] = "8";
    pixelSpecular[1] = "8";
    diffuseColor[0] = "1 1 1 1"; 
    diffuseColor[1] = "1 1 1 1"; 
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_glass_dmg)
{
    mapTo = "moonhawk_glass_dmg";
    diffuseMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    opacityMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "1 1 1 1.5";
    diffuseColor[1] = "1 1 1 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_glass_red_dmg)
{
    mapTo = "moonhawk_glass_red_dmg";
    diffuseMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    opacityMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "0.826 0.002 0.007 1.5";
    diffuseColor[1] = "0.826 0.002 0.007 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_glass_amber_dmg)
{
    mapTo = "moonhawk_glass_amber_dmg";
    diffuseMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    opacityMap[0] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[0] = "vehicles/common/glass_dmg_s.dds";
    normalMap[0] = "vehicles/common/glass_dmg_n.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_glass_dmg_d.dds";
    specularMap[1] = "vehicles/common/glass_dmg_s.dds";
    normalMap[1] = "vehicles/common/glass_dmg_n.dds";
    specularPower[0] = "128";
    specularPower[1] = "128";
    diffuseColor[0] = "0.774 0.242 0 1.5";
    diffuseColor[1] = "0.774 0.242 0 0.75";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(barstow_glass)
{
    mapTo = "barstow_glass";
    reflectivityMap[0] = "vehicles/common/glass_base.dds";
    diffuseMap[0] = "vehicles/barstow/barstow_glass_d.dds";
    opacityMap[0] = "vehicles/barstow/barstow_glass_d.dds";
    diffuseMap[1] = "vehicles/barstow/barstow_glass_da.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[1] = "0.5 0.5 0.5 0.75";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red_int)
{
    mapTo = "bus_red_int";
};  

singleton Material(bus_red_int)
{
    mapTo = "bus_red_int";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0 0 0.05";
    diffuseColor[1] = "0.8 0 0 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red_int_on)
{
    mapTo = "bus_red_int_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 1";
    diffuseColor[2] = "0.8 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red_on)
{
    mapTo = "bus_red_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 1";
    diffuseColor[2] = "0.8 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red_on_intense)
{
    mapTo = "bus_red_on_intense";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 2.8";
    diffuseColor[2] = "0.8 0 0 2.8";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_harzard)
{
    mapTo = "bus_amber_harzard";
};

singleton Material(bus_red_front_hazard)
{
    mapTo = "bus_red_front_hazard";
};

singleton Material(bus_red_front_hazard)
{
    mapTo = "bus_red_front_hazard";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0 0 0.05";
    diffuseColor[1] = "0.8 0 0 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red_front_hazard_on)
{
    mapTo = "bus_red_front_hazard_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0 0 1";
    diffuseColor[2] = "0.8 0 0 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
	glow[1] = "1";
    emissive[1] = "1";
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber)
{
    mapTo = "bus_amber";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 0.3";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_on)
{
    mapTo = "bus_amber_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_int)
{
    mapTo = "bus_amber_int";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 0.3";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
	glow[1] = "0";
    emissive[1] = "0";
	glow[2] = "0";
    emissive[2] = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_int_on)
{
    mapTo = "bus_amber_int_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
	 
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
	glow[1] = "1";
    emissive[1] = "0";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_signal_L)
{
    mapTo = "bus_amber_signal_L";
};

singleton Material(bus_amber_signal_L_int)
{
    mapTo = "bus_amber_signal_L_int";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_signal_L_on)
{
    mapTo = "bus_amber_signal_L_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_signal_R)
{
    mapTo = "bus_amber_signal_R";
};

singleton Material(bus_amber_signal_R_int)
{
    mapTo = "bus_amber_signal_R_int";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0.8 0.35 0.01 0.05";
    diffuseColor[1] = "0.8 0.35 0.01 0.3";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_amber_signal_R_on)
{
    mapTo = "bus_amber_signal_R_on";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 1";
    diffuseColor[2] = "0.8 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_white_light)
{
    mapTo = "bus_white_light";
};

singleton Material(bus_white_off)
{
    mapTo = "bus_white_off";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 0.05";
    diffuseColor[1] = "1 1 1 1.5";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_white_onn)
{
    mapTo = "bus_white_onn";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	
	specularMap[0] = "vehicles/common/null.dds";
	specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
	 
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    diffuseColor[2] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(bus_red)
{
    mapTo = "bus_red";
};

singleton Material(moonhawk_lights_on)
{
    mapTo = "moonhawk_lights_on";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
	
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    diffuseColor[2] = "1.5 1.5 1.5 0.15";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights_on_intense)
{
    mapTo = "moonhawk_lights_on_intense";
    diffuseMap[2] = "vehicles/moonhawk/moonhawk_lights_g.dds";
    specularMap[2] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[2] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "0.8 0.35 0.01 0.05";
    diffuseColor[2] = "1 0.35 0.01 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    useAnisotropic[2] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    glow[2] = "1";
    emissive[2] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights_dmg_alt)
{
    mapTo = "moonhawk_lights_dmg_alt";
    diffuseMap[0] = "vehicles/moonhawk/moonhawk_lights_dmg_d.dds";
    diffuseColor[0] = "1 1 1 1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights_dmg)
{
    mapTo = "moonhawk_lights_dmg";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_dmg_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_dmg_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_dmg_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_dmg_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights)
{
    mapTo = "moonhawk_lights";
    diffuseMap[1] = "vehicles/moonhawk/moonhawk_lights_d.dds";
    specularMap[1] = "vehicles/moonhawk/moonhawk_lights_s.dds";
    normalMap[1] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/moonhawk/moonhawk_lights_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[1] = "1.5 1.5 1.5 1";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(moonhawk_lights_alt)
{
    mapTo = "moonhawk_lights_alt";
    diffuseMap[0] = "vehicles/flatbus/moonhawk_lights_opac_d.dds";
	useAnisotropic[0] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    diffuseColor[0] = "1 1 1 1";
    dynamicCubemap = false;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(frame_bolt)
{
    mapTo = "frame_bolt";
    diffuseMap[1] = "frame_bolt_d";
    specularMap[1] = "frame_bolt_s";
    normalMap[1] = "frame_bolt_n";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "frame_bolt_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "128";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};

